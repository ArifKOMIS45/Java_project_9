package TestClass;

import org.junit.Test;

public class Test1 {

}
